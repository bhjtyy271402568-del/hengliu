"""Loss/thermal budget for one fan and local fins. Conditional air-speed model, not CFD."""
import json,math
from pathlib import Path
S=Path(__file__).parent
rho,cp,mu,kair=1.127,1007,1.92e-5,.0273 # air near 40 C
cfm=.00047194745
cases=[]
for vin,vo in [(42,30),(36,30),(32,30),(30,27),(42,6)]:
 duty=vo/vin;fs=220e3;I=40;di=vo*(1-duty)/(4.896e-6*fs);irms2=I*I+di*di/12
 ton=9e-9*(2.2+1+3*2.2)/(4.7-3.2);toff=9e-9*(2.2+1+3*1.3)/3.2
 hs_sw=.5*vin*(I/3)*(ton+toff)*fs*1.35 # typical charge/driver model, 35% planning allowance
 hs_cond=irms2/9*.0085*1.6*duty
 ls=irms2/9*.0125*1.6*(1-duty)+.3 # allowance for dead-time/recovery, not a measured bound
 hs=hs_sw+hs_cond;iin=vo*I/vin
 for _ in range(30):
  p1=(.6*iin)**2*.0112*1.6;p2=(.4*iin)**2*.0112*1.6;q4=iin*iin*.00145*1.6
  rs=iin*iin*.0012+I*I*.0012
  rest=6+4+rs # inductor incl estimated core loss, miscellaneous, shunts
  sink=p1+p2+q4+3*(hs+ls)
  iin=(vo*I+sink+rest)/vin
 cases.append(dict(Vin=vin,Vout=vo,Iout=I,Iin=iin,HS_each=hs,LS_each=ls,P1=p1,P2=p2,Q4=q4,sink_W=sink,total_main_W=sink+rest))

# Local skived sink: 80 x 45, 5 mm base + 25 mm fins, 32 fins of 0.8 mm thickness.
W,L,H,t,N=.080,.045,.025,.0008,32
gap=(W-N*t)/(N-1);area=(N-1)*gap*H;dh=2*gap*H/(gap+H)
def sink_dp(q,K):
 v=q/area;re=rho*v*dh/mu;aspect=gap/H
 po=96*(1-1.3553*aspect+1.9467*aspect**2-1.7012*aspect**3+.9564*aspect**4-.2537*aspect**5)
 f=po/max(re,1e-6)
 return (f*L/dh+K)*rho*v*v/2
def r_sink(q):
 # Assumed Nu=6 for an approximate parallel-fin channel model; no entrance/radiation credit.
 # Open airflow, spreading, nonuniformity and bypass still require measurement.
 Nu=6.
 h=Nu*kair/dh;m=math.sqrt(2*h/(180*t));eta=math.tanh(m*H)/(m*H)
 conv=1/(h*(2*N*H*L*eta+(N-1)*gap*L))
 return conv+1/(2*rho*cp*q)+.08 # explicit assumed spreading/contact-to-base allowance
flow=[]
for speed in [1,1.5,2,2.5,3,4]:
 q=speed*area;resistance=r_sink(q);base=40+60*resistance
 flow.append(dict(assumed_mean_channel_speed_m_s=speed,sink_CFM=q/cfm,sink_R_K_W=resistance,
  base_C_at_60W=base,HS_junction_C_if_Rjs_5p5=base+9*5.5,
  channel_pressure_estimate_Pa=[sink_dp(q,K) for K in [2,8]],
  warning='Channel speed is a condition to verify, not a result inferred from fan free-air flow.'))

requirements={'ambient_inlet_C':40,'constant_current_output_W':1200,'aux_output_budget_W':126,
 'sink_design_load_W':60,'whole_stack_design_heat_W':107,'sink_R_max_K_W':.55,
 'sink_mean_channel_air_speed_target_m_s':2.5,
 'junction_limit_C':125,'junction_to_sink_requirements_K_W':{'HS':5.5,'LS':7,'P':3,'Q4':6},
 'component_design_loss_W':{'HS':9,'LS':4,'P':12,'Q4':5},
 'note':'Targets are acceptance requirements, not achieved values. Current PCB has no finalized thermal-via/copper network.'}
temps={key:40+60*.55+power*requirements['junction_to_sink_requirements_K_W'][key] for key,power in requirements['component_design_loss_W'].items()}
r={'conditions':requirements,'loss_cases_W':cases,'loss_model_limits':['Hot Rds factor 1.6 is an assumption','Switching loss uses typical charge/driver impedance, not measured switching energy','P MOS current split assumed 60/40','Low-input full-power cases are thermal stress references, not a guarantee that electrical input current limit permits them'],
 'sink_geometry_mm':{'width':80,'length':45,'base':5,'fin_height':25,'fin_count':32,'fin_thickness':.8,'fin_gap':gap*1000},
 'open_air_velocity_sensitivity':flow,'temperatures_if_requirements_met_C':temps,
 'warning':'No CFD performed. No duct is used. Actual channel flow and sink thermal resistance must be measured; fan free-air rating does not determine either. Assembly alone is not a 1.2kW thermal signoff.'}
(S/'thermal-calculations.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'loss_cases':cases,'flow':flow,'target_temperatures':temps},indent=2))
